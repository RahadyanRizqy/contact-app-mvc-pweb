<?php
define('BASEURL', 'http://localhost/p9/');