<?php
switch ($url[0]) {
    
    case 'dashboard':
        if (isset($url[1]) && $url[1] == 'logout') {
            AuthController::logout();
        }
        else {
            DashboardController::index($url);
        }
        break;

    case 'login':
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            AuthController::saveLogin();
        }
        else {
            AuthController::login();
        }
        break;

    case 'register':
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            AuthController::saveRegister();
        }
        else {
            AuthController::register();
        }
        break;

    case 'freshdb':
        freshdb();
        break;

    default:
        view('home');
}