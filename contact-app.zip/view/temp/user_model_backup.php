<?php

include_once 'config/conn.php';

class User {
    static function login($data=[]) {
        extract($data);
        global $conn;
        $sql = "SELECT * FROM users WHERE email = '$email' AND password = '$password'";
        $result = $conn->query($sql);

        $result = $result->fetch_assoc();
        return $result;
    }

    static function register($data=[]) {
        extract($data);
        global $conn;
        $inserted_at = date('Y-m-d H:i:s', strtotime('now'));
        $sql = "INSERT INTO users SET name = ?, email = ?, password = ?, inserted_at = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('ssss', $name, $email, $password, $inserted_at);
        $stmt->execute();

        $result = $stmt->affected_rows > 0 ? true : false;
        return $result;
    }

    static function update($id, $data=[]) {
        extract($data);
        global $conn;
        $updated_at = date('Y-m-d H:i:s', strtotime('now'));

        $result = "";
        foreach ($assocArray as $key => $value) {
            $result .= $key . " = " . "'$value'" . ", ";
        }
        $result = rtrim($result, ", ");

        $sql = "UPDATE users SET $result WHERE id = $id";
        $conn->query($sql);

        $result = $conn->affected_rows > 0 ? true : false;
        return $result;
    }

    static function delete($id) {
        global $conn;
        $sql = "DELETE FROM users WHERE id = '$id'";
        $conn->query($sql);

        $result = $conn->affected_rows > 0 ? true : false;
        return $result;
    }
}